# Add project specific ProGuard rules here.
# Minification is off by default for this project (see build.gradle.kts),
# so these rules are not applied unless you turn isMinifyEnabled on.
